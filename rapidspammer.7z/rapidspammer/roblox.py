import tkinter as tk
from tkinter import messagebox
import threading
import time
import pyautogui
import keyboard

spamming = False
spam_thread = None
user_hotkey = "F8"  # default hotkey

def toggle_spam():
    if not spamming:
        start_spam()
    else:
        stop_spam()

def start_spam():
    global spamming, spam_thread

    message = entry_message.get()
    try:
        count = int(entry_count.get())
        delay = float(entry_delay.get())
    except ValueError:
        messagebox.showerror("Invalid Input", "Count must be an integer, delay must be a number.")
        return

    if not message:
        messagebox.showerror("Empty Message", "Please enter a message to spam.")
        return

    spamming = True
    button_start.config(state="disabled")
    button_stop.config(state="normal")

    def spam():
        time.sleep(5)  # Time to switch to the target window
        for i in range(count):
            if not spamming:
                break
            pyautogui.typewrite(message)
            pyautogui.press('enter')
            time.sleep(delay)
        stop_spam()

    spam_thread = threading.Thread(target=spam)
    spam_thread.start()

def stop_spam():
    global spamming
    spamming = False
    button_start.config(state="normal")
    button_stop.config(state="disabled")

def set_hotkey():
    global user_hotkey
    new_hotkey = entry_hotkey.get().strip()

    if not new_hotkey:
        messagebox.showerror("Invalid Hotkey", "Please enter a valid hotkey.")
        return

    try:
        keyboard.remove_hotkey(user_hotkey)
    except KeyError:
        pass  # First time setting the hotkey

    user_hotkey = new_hotkey
    keyboard.add_hotkey(user_hotkey, toggle_spam)
    label_status.config(text=f"Hotkey set to: {user_hotkey.upper()}")

# GUI setup
root = tk.Tk()
root.title("Rapid's Spammer Tool")
root.geometry("320x290")
root.resizable(False, False)

tk.Label(root, text="Message to spam:").pack(pady=5)
entry_message = tk.Entry(root, width=30)
entry_message.pack()

tk.Label(root, text="How many times:").pack(pady=5)
entry_count = tk.Entry(root, width=10)
entry_count.pack()

tk.Label(root, text="Delay (seconds):").pack(pady=5)
entry_delay = tk.Entry(root, width=10)
entry_delay.insert(0, "0.01")
entry_delay.pack()

tk.Label(root, text="Choose toggle hotkey:").pack(pady=5)
entry_hotkey = tk.Entry(root, width=10)
entry_hotkey.insert(0, "F8")
entry_hotkey.pack()

button_set_hotkey = tk.Button(root, text="Set Hotkey", command=set_hotkey)
button_set_hotkey.pack(pady=5)

label_status = tk.Label(root, text="Default hotkey: F8")
label_status.pack()

button_start = tk.Button(root, text="Start Spamming", command=start_spam, bg="green", fg="white")
button_start.pack(pady=10)

button_stop = tk.Button(root, text="Stop", command=stop_spam, state="disabled", bg="red", fg="white")
button_stop.pack()

tk.Label(root, text="Switch to target app in 5 sec.").pack(pady=5)

# Set default hotkey
keyboard.add_hotkey(user_hotkey, toggle_spam)

root.mainloop()
